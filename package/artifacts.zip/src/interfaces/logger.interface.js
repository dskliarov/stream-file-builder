"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Level;
(function (Level) {
    Level[Level["DEBUG"] = 0] = "DEBUG";
    Level[Level["INFO"] = 1] = "INFO";
    Level[Level["AUDIT"] = 2] = "AUDIT";
    Level[Level["ERROR"] = 3] = "ERROR";
    Level[Level["FATAL"] = 4] = "FATAL";
})(Level = exports.Level || (exports.Level = {}));
