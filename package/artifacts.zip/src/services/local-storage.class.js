"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
var inversify_1 = require("inversify");
require("reflect-metadata");
var types_1 = require("../utilities/types");
var fs = __importStar(require("fs"));
var LocalStorage = /** @class */ (function () {
    function LocalStorage(logger) {
        this._logger = logger;
    }
    LocalStorage.prototype.put = function (key, chunkNumber, chunk) {
        var filename = this.filename(key, chunkNumber);
        var logger = this._logger;
        return new Promise(function (resolve, reject) {
            fs.writeFile(filename, chunk, function (err) {
                if (err) {
                    logger.error(err.message, []);
                    reject(err);
                }
                logger.info("File ${filename} created", []);
                resolve(true);
            });
        });
    };
    LocalStorage.prototype.get = function (key, chunkNumber) {
        var filename = this.filename(key, chunkNumber);
        var logger = this._logger;
        return new Promise(function (resolve, reject) {
            fs.readFile(filename, function (err, data) {
                if (err) {
                    logger.error(err.message, []);
                    reject(err);
                }
                logger.info("File ${filename} read", []);
                resolve(data.toString());
            });
        });
    };
    LocalStorage.prototype.delete = function (key, chunkNumber) {
        var filename = this.filename(key, chunkNumber);
        var logger = this._logger;
        return new Promise(function (resolve, reject) {
            fs.unlink(filename, function (err) {
                if (err) {
                    logger.error(err.message, []);
                    reject(err);
                }
                logger.info("File ${filename} have been deleted", []);
                resolve(true);
            });
        });
    };
    LocalStorage.prototype.filename = function (key, chunkNumber) {
        var sanitize = require("sanitize-filename");
        var sanitizeKey = sanitize(key);
        return sanitizeKey + "-" + chunkNumber;
    };
    LocalStorage = __decorate([
        inversify_1.injectable(),
        __param(0, inversify_1.inject(types_1.TYPES.ILogger)),
        __metadata("design:paramtypes", [Object])
    ], LocalStorage);
    return LocalStorage;
}());
exports.LocalStorage = LocalStorage;
