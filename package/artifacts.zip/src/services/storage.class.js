"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
var inversify_1 = require("inversify");
require("reflect-metadata");
var types_1 = require("../utilities/types");
var AWS = __importStar(require("aws-sdk"));
var Storage = /** @class */ (function () {
    function Storage(config, logger) {
        this._s3 = new AWS.S3({ apiVersion: '2006-03-01' });
        this._config = config;
        this._logger = logger;
    }
    Storage.prototype.put = function (key, chunks) {
        var _this = this;
        var params = {
            Body: JSON.stringify(chunks),
            Bucket: this._config.s3Bucket(),
            Key: key,
            ContentType: 'application/json'
        };
        var logger = this._logger;
        return new Promise(function (resolve, reject) {
            _this._s3.putObject(params).promise().then(function (data) {
                logger.info("Success S3 PUT operation", []);
                resolve(true);
            }).catch(function (err) {
                _this._logger.error(err.message, []);
                reject(false);
            });
        });
    };
    Storage.prototype.get = function (key) {
        var _this = this;
        var params = {
            Bucket: this._config.s3Bucket(),
            Key: key,
        };
        return new Promise(function (resolve, reject) {
            _this._s3.getObject(params).promise().then(function (data) {
                _this._logger.info("Success S3 GET operation", []);
                data.Body;
                resolve(data.Body ? JSON.parse(data.Body.toString()) : []);
            }).catch(function (err) {
                _this._logger.error(err.message, []);
                reject(false);
            });
        });
    };
    Storage.prototype.delete = function (key) {
        var _this = this;
        var params = {
            Bucket: this._config.s3Bucket(),
            Key: key,
        };
        return new Promise(function (resolve, reject) {
            _this._s3.deleteObject(params).promise().then(function (data) {
                _this._logger.info("Success S3 DELETE operation", []);
                resolve(true);
            }).catch(function (err) {
                _this._logger.error(err.message, []);
                reject(false);
            });
        });
    };
    Storage = __decorate([
        inversify_1.injectable(),
        __param(0, inversify_1.inject(types_1.TYPES.IConfig)),
        __param(1, inversify_1.inject(types_1.TYPES.ILogger)),
        __metadata("design:paramtypes", [Object, Object])
    ], Storage);
    return Storage;
}());
exports.Storage = Storage;
