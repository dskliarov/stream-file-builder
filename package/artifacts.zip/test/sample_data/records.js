"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
var randomstring = __importStar(require("randomstring"));
var js_base64_1 = require("js-base64");
var data = function () {
    var randomcontent = function () {
        var str = randomstring.generate({
            length: 1024,
            charset: 'hex'
        });
        return js_base64_1.Base64.encode(str);
    };
    var sample = function (partition, partitionCount, key) {
        /**
         * Payload schema
         * {
         *   "putEndpoint" : "https://www.example.com/image.jpg",
         *   "partition": partition,
         *   "partitionCount": partitionCount,
         *   "content" : "aGVsbG8gd29ybGQh"
         * }
         */
        return {
            putEndpoint: "https://" + key,
            partition: partition,
            partitionCount: partitionCount,
            content: randomcontent()
        };
    };
    return [
        sample(1, 3, "key1"),
        sample(2, 3, "key1"),
        sample(3, 3, "key1"),
        sample(1, 3, "key2"),
        sample(3, 3, "key2")
    ];
};
exports.sampleData = data;
